#!/bin/bash
touch inputFile
RANDON=$$
i=0
for i in `seq 10`
do 
echo $i, $RANDOM >> inputFile
done
