1. $docker pull infracloudio/csvserver
2. $docker ps/ $docker ps -a
3. $docker run -it -d infracloudio/csvserver
4. Creating a gencsv.sh file and inputFile
5. $docker run -it -d -v <source_file_path>:/csvserver/inputdata infracloudio/csvserver
6. $docker run -it -d -p 9393:9300 -v <source_file_path>:/csvserver/inputdata infracloudio/csvserver
7. $docker inspect <conatiner id>
8. $docker ifconfig
9. $docker run -it -d -p 127.0.0.1:9393:9300 -v <source_file_path>:/csvserver/inputdata infracloudio/csvserver
10. WebPage - http://127.0.0.1:9393/
11. $docker run -it -d -p 127.0.0.1:9393:9300 -e CSVSERVER=Orange -v <source_file_path>:/csvserver/inputdata infracloudio/csvserver
 
